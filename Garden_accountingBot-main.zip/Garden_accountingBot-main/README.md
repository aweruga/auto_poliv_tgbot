# Garden_accountingBot
@sadovnikpolyana_bot
Garden accounting bot - a bot that keeps records of tree processing. 
The bot can process trees and make changes to the database. 
The bot can add a tree to the database and much more
https://t.me/sadovnikpolyana_bot
